export const stocks = [
	{
		product_id: '1',
		count: 5,
	},
	{
		product_id: '2',
		count: 12,
	},
	{
		product_id: '3',
		count: 4,
	},
	{
		product_id: '4',
		count: 8,
	},
	{
		product_id: '5',
		count: 6,
	},
	{
		product_id: '6',
		count: 98,
	},
	{
		product_id: '7',
		count: 15,
	},
	{
		product_id: '8',
		count: 74,
	},
	{
		product_id: '9',
		count: 36,
	},
	{
		product_id: '10',
		count: 56,
	},
	{
		product_id: '11',
		count: 12,
	},
	{
		product_id: '12',
		count: 14,
	},
	{
		product_id: '13',
		count: 7,
	},
	{
		product_id: '14',
		count: 9,
	},
	{
		product_id: '15',
		count: 10,
	},
	{
		product_id: '16',
		count: 65,
	},
	{
		product_id: '17',
		count: 11,
	},
	{
		product_id: '18',
		count: 4,
	},
	{
		product_id: '19',
		count: 6,
	},
	{
		product_id: '20',
		count: 16,
	},
];
