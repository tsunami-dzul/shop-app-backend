export const products = [
	{
		id: '1',
		title: 'Nokia',
		description: 'Nokia v1',
		price: 254,
	},
	{
		id: '2',
		title: 'Pantech',
		description: 'Pantech v1.2. With camara, games and night light',
		price: 157,
	},
	{
		id: '3',
		title: 'Android',
		description:
			'Android IceCream. The most rescent model with 6GB storing capacity, camara of 2.1, 2G network',
		price: 682,
	},
	{
		id: '4',
		title: 'GameFactor keyboard. Gaming keyboad',
		description:
			'Game factor keyboard. Night light, hergonomic and programatically keys.',
		price: 658,
	},
	{
		id: '5',
		title: 'Vorago WideScreen',
		description: 'Vorago wide screen 12", HDMI high quality.',
		price: 1248,
	},
	{
		id: '6',
		title: 'Vorago Screen',
		description:
			'Vorago normal screen with HDMI, 10", controls to regulate color and contrats',
		price: 365,
	},
	{
		id: '7',
		title: 'Pantech cell phone',
		description: 'Pantech cell phone with camara, 2GB, 3G and 3G connectivity.',
		price: 487,
	},
	{
		id: '8',
		title: 'Logitech Horns',
		description: 'Horns high quality, buffer and spectrum sound round.',
		price: 654,
	},
	{
		id: '9',
		title: 'Logitech home teather',
		description:
			'Home teather horns, output 46.2, gigh quality sounds and buffer integrated.',
		price: 897,
	},
	{
		id: '10',
		title: 'Huawei headset',
		description:
			'Huawei bluetooth headset, 12 hout duration, sound cancelation and high sound quality.',
		price: 654,
	},
	{
		id: '11',
		title: 'Huawei headset',
		description:
			'Headset with cable connection, special sound and sound cancelation.',
		price: 354,
	},
	{
		id: '12',
		title: 'Pantech cell phone',
		description:
			'Pantech cell phone, 6GB of store, ti supports mp3 and mp4 formats, the best sound in the market.',
		price: 753,
	},
	{
		id: '13',
		title: 'Nokia cell phone',
		description:
			'Nokia cell phone, with all the aditaments, GBM connectivity and storing of 4G, maximum system reproduction.',
		price: 159,
	},
	{
		id: '14',
		title: 'Nokia smartphone',
		description: 'Nokia version 8.1, the best experience of smartphone.',
		price: 951,
	},
	{
		id: '15',
		title: 'Nokia smartphone',
		description:
			'Nokia version 9.4 with Android sysmtem version  Plugi, 12GB of store capacity, Spotify and the best app.',
		price: 852,
	},
	{
		id: '16',
		title: 'Huawei screen',
		description:
			'Screen of 18", with HDMI and controls to handle the screen colors, contrats. With warm system',
		price: 258,
	},
	{
		id: '17',
		title: 'Cannon printer',
		description:
			'Cannon printer injection. All the quality to print documents, pictures and more. System of full link injection.',
		price: 658,
	},
	{
		id: '18',
		title: 'Logitech keyboard',
		description: 'Keyboard mini, 20cm, with key ilumination',
		price: 452,
	},
	{
		id: '19',
		title: 'Logitech headset',
		description:
			'Soround quality, volumes controls and sound external cancelation',
		price: 325,
	},
	{
		id: '20',
		title: 'Cannon printer',
		description: 'Laser printer, black and white.',
		price: 985,
	},
];
