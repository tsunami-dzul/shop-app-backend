# Links to lambdas

## getProductLits:

method: GET  
url: https://e87hrm9xod.execute-api.us-west-1.amazonaws.com/dev/products

## getProductById:

method: GET  
url: https://e87hrm9xod.execute-api.us-west-1.amazonaws.com/dev/products/{productId}

## createProducts:

method: PUT  
url: https://e87hrm9xod.execute-api.us-west-1.amazonaws.com/dev/products
